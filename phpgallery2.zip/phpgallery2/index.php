<?php
	# SETTINGS
	$max_width = 100;
	$max_height = 100;
	$per_page = 31;
	
	$page = $_GET['page'];
	
	$has_previous = false;
	$has_next = false;
	
	function getPictures() {
		global $page, $per_page, $has_previous, $has_next;
		if ( $handle = opendir(".") ) {
			$lightbox = rand();
			echo '<ul id="pictures">';
			
			$count = 0;
			$skip = $page * $per_page;
			
			if ( $skip != 0 )
				$has_previous = true;
			
			while ( $count < $skip && ($file = readdir($handle)) !== false ) {
				if ( !is_dir($file) && ($type = getPictureType($file)) != '' )
					$count++;
			}
			$count = 0;
			while ( $count < $per_page && ($file = readdir($handle)) !== false ) {
				if ( !is_dir($file) && ($type = getPictureType($file)) != '' ) {
					if ( ! is_dir('thumbs') ) {
						mkdir('thumbs');
					}
					if ( ! file_exists('thumbs/'.$file) ) {
						makeThumb( $file, $type );
					}
					echo '<li><a href="'.$file.'" rel="lightbox['.$lightbox.']">';
					echo '<img src="thumbs/'.$file.'" alt="" />';
					echo '</a></li>';
					$count++;
				}
			}
			echo '</ul>';
			
			while ( ($file = readdir($handle)) !== false ) {
				if ( !is_dir($file) && ($type = getPictureType($file)) != '' ) {
					$has_next = true;
					break;
				}
			}
		}
	}
	
	function getPictureType($file) {
		$split = explode('.', $file); 
		$ext = $split[count($split) - 1];
		if ( preg_match('/jpg|jpeg/i', $ext) ) {
			return 'jpg';
		} else if ( preg_match('/png/i', $ext) ) {
			return 'png';
		} else if ( preg_match('/gif/i', $ext) ) {
			return 'gif';
		} else {
			return '';
		}
	}
	
	function makeThumb( $file, $type ) {
		global $max_width, $max_height;
		if ( $type == 'jpg' ) {
			$src = imagecreatefromjpeg($file);
		} else if ( $type == 'png' ) {
			$src = imagecreatefrompng($file);
		} else if ( $type == 'gif' ) {
			$src = imagecreatefromgif($file);
		}
		if ( ($oldW = imagesx($src)) < ($oldH = imagesy($src)) ) {
			$newW = $oldW * ($max_width / $oldH);
			$newH = $max_height;
		} else {
			$newW = $max_width;
			$newH = $oldH * ($max_height / $oldW);
		}
		$new = imagecreatetruecolor($newW, $newH);
		imagecopyresampled($new, $src, 0, 0, 0, 0, $newW, $newH, $oldW, $oldH);
		if ( $type == 'jpg' ) {
			imagejpeg($new, 'thumbs/'.$file);
		} else if ( $type == 'png' ) {
			imagepng($new, 'thumbs/'.$file);
		} else if ( $type == 'gif' ) {
			imagegif($new, 'thumbs/'.$file);
		}
		imagedestroy($new);
		imagedestroy($src);
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UFT-8" />
<title>Pictures</title>
<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="screen" />
<h1>Pagination on Photo Gallery</h1>
<style type="text/css">
body {
	width:780px;
	margin:0 auto;
}
#pictures li {
	float:left;
	height:<?php echo ($max_height + 10); ?>px;
	list-style:none outside;
	width:<?php echo ($max_width + 10); ?>px;
	text-align:center;
}
img {
	border:0;
	outline:none;
}
.prev {
	float:left;
}
.next {
	float:right;
}
</style>
</head>
<body>

<?php getPictures(); ?>

<div style="clear:both"></div>

<?php
	if ( $has_previous )
		echo '<p class="prev"><a href="?page='.($page - 1).'">&larr; Previous Page</a></p>';

	if ( $has_next )
		echo '<p class="next"><a href="?page='.($page + 1).'">Next Page &rarr;</a></p>';
?>

<div style="clear:both"></div>

<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/scriptaculous.js?load=effects,builder"></script>
<script type="text/javascript" src="js/lightbox.js"></script>
</body>
</html>
